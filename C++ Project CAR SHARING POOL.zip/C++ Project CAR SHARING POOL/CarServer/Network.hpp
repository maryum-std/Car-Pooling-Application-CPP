#pragma once

//network class containing method that defines the server
class Network
{
public:
	void serverManage(void);

};

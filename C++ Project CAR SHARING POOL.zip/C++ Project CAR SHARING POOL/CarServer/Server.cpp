#include "Service.hpp"
#include "Network.hpp"

int main()
{
	//creating object for network class
	Network net;

	//calling method for running the server
	net.serverManage();
	return 0;
}



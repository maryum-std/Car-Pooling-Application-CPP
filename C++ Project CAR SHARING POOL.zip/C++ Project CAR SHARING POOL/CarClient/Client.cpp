#include<iostream>
#include "Input.hpp"


int main()
{
	//calling method for getting data and display user from user
	input();
	system("PAUSE");

	return 0;
}
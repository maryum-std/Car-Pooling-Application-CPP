#pragma once


//method declaration for getting data and displaying info to the user
void input(void);